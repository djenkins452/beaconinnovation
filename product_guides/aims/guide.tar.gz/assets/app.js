/*  AIMS — Advanced Inventory Management System
    Copyright © 2026 Beacon Innovation, LLC. All rights reserved. Proprietary and Confidential.
    Component: Tooling · Developer Guide — client behavior (theme, search, nav)
    Status: Development
    DOCUMENTATION: DEVELOPER_GUIDE_ARCHITECTURE.md Part II §22 (search); DECISIONS.md D-176
    No external dependency, no network, no telemetry. Search runs entirely on the
    build-time index in search-index.js (window.DEVGUIDE_INDEX).                       */
(function () {
  "use strict";

  /* ---- theme: System / Light / Dark, persisted locally --------------------- */
  var root = document.documentElement, KEY = "aims-devguide-theme";
  var saved = localStorage.getItem(KEY) || "";
  if (saved) root.setAttribute("data-theme", saved);
  var tbtn = document.getElementById("theme");
  function label() {
    var t = root.getAttribute("data-theme");
    tbtn.textContent = t === "light" ? "☀" : t === "dark" ? "☾" : "◐";
    tbtn.setAttribute("aria-label", "Theme: " + (t || "system") + " — click to change");
  }
  if (tbtn) {
    label();
    tbtn.addEventListener("click", function () {
      var order = ["", "light", "dark"], cur = root.getAttribute("data-theme") || "";
      var next = order[(order.indexOf(cur) + 1) % order.length];
      if (next) { root.setAttribute("data-theme", next); localStorage.setItem(KEY, next); }
      else { root.removeAttribute("data-theme"); localStorage.removeItem(KEY); }
      label();
    });
  }

  /* ---- optional "Open in GitHub" (only when a base is configured) ---------- */
  // Configure once in the browser console to enable, e.g.:
  //   localStorage.setItem('aims-repo-base','https://github.com/djenkins452/aims/blob/main/')
  var base = localStorage.getItem("aims-repo-base");
  if (base) {
    document.querySelectorAll("a.gh[data-path]").forEach(function (a) {
      a.href = base.replace(/\/$/, "") + "/" + a.getAttribute("data-path");
      a.hidden = false; a.target = "_blank"; a.rel = "noopener";
    });
  }

  /* ---- copy path ----------------------------------------------------------- */
  document.querySelectorAll(".copy[data-copy]").forEach(function (b) {
    b.addEventListener("click", function () {
      var v = b.getAttribute("data-copy");
      (navigator.clipboard ? navigator.clipboard.writeText(v) : Promise.reject())
        .then(function () { var t = b.textContent; b.textContent = "Copied ✓";
          setTimeout(function () { b.textContent = t; }, 1200); })
        .catch(function () { b.textContent = "Copy failed"; });
    });
  });

  /* ---- decision-index filter ---------------------------------------------- */
  var df = document.getElementById("decfilter"), dl = document.getElementById("declist");
  if (df && dl) {
    df.addEventListener("input", function () {
      var q = df.value.toLowerCase();
      dl.querySelectorAll("li").forEach(function (li) {
        li.style.display = li.textContent.toLowerCase().indexOf(q) >= 0 ? "" : "none";
      });
    });
  }

  /* ---- search -------------------------------------------------------------- */
  var idx = window.DEVGUIDE_INDEX || [];
  var input = document.getElementById("q"), box = document.getElementById("results");
  var sel = -1, cur = [];

  function score(item, q, terms) {
    var name = item.n.toLowerCase(), path = (item.p || "").toLowerCase();
    var base = (item.x || "").toLowerCase(), s = 0;
    if (name === q) s += 1000;                                   // exact identifier / name
    if (path === q || (item.p && item.p.split("/").pop().toLowerCase() === q)) s += 900; // exact filename
    if (item.t === "DECISION" && name.indexOf(q) === 0) s += 850; // D-### prefix
    if (name.indexOf(q) === 0) s += 200;                          // name prefix
    for (var i = 0; i < terms.length; i++) {
      var t = terms[i]; if (!t) continue;
      if (name.indexOf(t) >= 0) s += 60;
      if (base.indexOf(t) >= 0) s += 18;
      if (path.indexOf(t) >= 0) s += 12;
    }
    if (!s) return 0;
    if (item.a === "Authoritative") s += 8;                       // authority weighting
    s -= (item.o || 0);                                           // type order tiebreak
    return s;
  }

  function run(q) {
    q = q.trim().toLowerCase();
    if (!q) { hide(); return; }
    var terms = q.split(/\s+/);
    var out = [];
    for (var i = 0; i < idx.length; i++) {
      var sc = score(idx[i], q, terms);
      if (sc > 0) out.push([sc, idx[i]]);
    }
    out.sort(function (a, b) { return b[0] - a[0]; });
    cur = out.slice(0, 30).map(function (r) { return r[1]; });
    render();
  }

  function render() {
    if (!cur.length) { box.innerHTML = "<li class='empty' aria-disabled='true'>No matches</li>";
      show(); return; }
    box.innerHTML = cur.map(function (it, i) {
      var p = it.p ? "<span class='rp'>" + it.p + "</span>" : "";
      return "<li role='option' data-u='" + it.u + "' aria-selected='" + (i === sel) + "'>" +
        "<span class='rt'>" + it.t + "</span><span class='rn'>" + escapeHtml(it.n) + "</span>" + p + "</li>";
    }).join("");
    Array.prototype.forEach.call(box.children, function (li, i) {
      if (li.dataset.u) li.addEventListener("click", function () { go(i); });
    });
    show();
  }
  function escapeHtml(s){var d=document.createElement("span");d.textContent=s;return d.innerHTML;}
  function show(){ box.hidden = false; input.setAttribute("aria-expanded","true"); }
  function hide(){ box.hidden = true; sel = -1; input.setAttribute("aria-expanded","false"); }
  function go(i){ if (cur[i]) location.href = cur[i].u; }

  if (input && box) {
    input.addEventListener("input", function () { sel = -1; run(input.value); });
    input.addEventListener("keydown", function (e) {
      if (e.key === "ArrowDown") { e.preventDefault(); sel = Math.min(sel + 1, cur.length - 1); paint(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); sel = Math.max(sel - 1, 0); paint(); }
      else if (e.key === "Enter") { e.preventDefault(); go(sel < 0 ? 0 : sel); }
      else if (e.key === "Escape") { input.value = ""; hide(); input.blur(); }
    });
    function paint() {
      Array.prototype.forEach.call(box.children, function (li, i) {
        if (!li.dataset.u) return;
        li.setAttribute("aria-selected", i === sel);
        if (i === sel) li.scrollIntoView({ block: "nearest" });
      });
    }
    document.addEventListener("click", function (e) {
      if (!e.target.closest(".search")) hide();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "/" && document.activeElement !== input &&
          !/^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName)) {
        e.preventDefault(); input.focus();
      }
    });
  }
})();
